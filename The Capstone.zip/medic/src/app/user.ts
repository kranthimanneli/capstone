export class User {
    id:number;
    name:string;
    emailid:string
    pwd:string
}
